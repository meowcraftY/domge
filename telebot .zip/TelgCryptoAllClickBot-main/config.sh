apt update && apt upgrade
apt install python python2 -y
pip install --upgrade pip
pip install wheel
pip install asyncio
pip install telethon
pip install colorama
pip install bs4
pip install rsa
pip install requests
pip install pyaes
pip install async_generator
termux-setup-storage
chmod 777 start.sh
