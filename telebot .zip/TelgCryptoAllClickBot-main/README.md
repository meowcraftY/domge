# TelgCryptoAllClickBot

Mine BTC, BCH, LTC, DOGE using telegram click bots on Termux.

<h2>Requirement*</h2>

1. Termux update version.

2. Telegram account

<h3>Join The Bot :-</3>


BTC  :- https://t.me/BitcoinClick_bot?start=eKFCp

BCH  :- https://t.me/BCH_clickbot?start=OMoJB

LTC  :- https://t.me/Litecoin_click_bot?start=9YCuZ

DOGE :- https://t.me/Dogecoin_click_bot?start=KRxBt

<h2>How to Configer the script</h2>

pkg update && pkg upgrade

cd TelgCryptoAllClickBot

bash config.sh

<h4>change the number</h4>

nano Numbers.txt

Enter your number with your country code then press ctrl+O and then press enter and then ctrl + X

python clickbotsNonstopv6.py


<h4>To get The access password an link provide on script</h4>
Donate:-

BTC : 17sdPPfEVsppaxLYG86Zj1fv31jSrRkkYm

DOGE: D912QexbUYismQiMxWwKnqU8HhUAzyK3XW

LTC : LMeeG911Gu32XnSPf1iw2z9VmwWSEKwmjX

ZEC : t1NPYTM4mbu3TiT2E4yneW5MUP8MKAxkn2f

BCH : qq5n5gj4p5q0e9esyt276ujztr4casdw75yj8j79nc
